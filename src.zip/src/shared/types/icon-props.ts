export interface IconProps {
  className?: string;
  size?: number;
}