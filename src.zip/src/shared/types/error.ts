export interface Error {
  status: number;
  message: string;
  code: string;
}