export interface SearchParams<T> {
  searchParams: Promise<T>;
}