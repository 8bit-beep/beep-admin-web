export interface SegmentItem {
  label: string;
  value: string;
}