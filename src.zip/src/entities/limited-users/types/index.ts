export interface LimitedUser {
  id: number;
  email: string;
}