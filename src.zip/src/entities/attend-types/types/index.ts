export interface AttendType {
  id: number;
  name: string;
}
