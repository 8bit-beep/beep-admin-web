export interface Checkpoint {
  id: number;
  name: string;
  startAt: string;
  endAt: string;
  attendanceStartAt: string;
  attendanceEndAt: string;
}