export interface Room {
  id: number;
  name: string;
  grade: number | null;
  classNumber: number | null;
  floor: number;
}