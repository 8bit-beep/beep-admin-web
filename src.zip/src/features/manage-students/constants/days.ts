export const DAYS = [
  { label: "전체", value: "ALL" },
  { label: "월요일", value: "MONDAY" },
  { label: "화요일", value: "TUESDAY" },
  { label: "수요일", value: "WEDNESDAY" },
  { label: "목요일", value: "THURSDAY" },
];