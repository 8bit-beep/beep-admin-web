import { DropdownItem } from "@bds-web/ui";

export const FLOOR_OPTIONS: DropdownItem[] = [
  { name: "1층", value: "1" },
  { name: "2층", value: "2" },
  { name: "3층", value: "3" },
  { name: "실습동 외", value: "others" },
];
