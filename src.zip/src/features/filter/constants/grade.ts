export const GRADE_OPTIONS = [
  { name: "1학년", value: "1" },
  { name: "2학년", value: "2" },
  { name: "3학년", value: "3" },
];