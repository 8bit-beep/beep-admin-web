export interface TableHeader {
  title: string;
  width?: string;
}