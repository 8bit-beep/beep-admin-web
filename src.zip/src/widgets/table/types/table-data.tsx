import { ReactNode } from "react";

export interface TableData {
  data: ReactNode[];
}